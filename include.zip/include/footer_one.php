<section class="footer-bottom-area style3">
       <div class="container">
           <div class="row">

               <div class="col-md-6 col-12 text-center">
                   <span class="copyright-text">Copyright © 2024 <a href="index.php" class="text-primary">
                   GAI India Hospitality Solutions</a> All Rights Reserved.</span>
               </div>

               <div class="col-md-6 col-12 text-center">
                   <span class="copyright-text">Designed &amp; Developed By <a href="https://www.weblinkservices.net"
                           class="text-primary" target="_blank"> <img src="images/wlspl_logo.png "
                               width="130 "></a></span>
               </div>

           </div>
       </div>
   </section>
   <!--End footer bottom area-->

   </div>


   <div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-angle-up"></span></div>

   <a href="https://wa.link/385d89" target="_blank"><img class="circle1 pulse" src="images/whatsapp.png" alt="whatsapp"
           width="30"></a>
   <a href="tel:+917588800333"><img class="circle2 pulse" src="images/c.png" width="30"></a>
   
   <script src="js/jquery.js"></script>
   <script src="js/appear.js"></script>
   <script src="js/bootstrap.bundle.min.js"></script>
   <script src="js/bootstrap-select.min.js"></script>
   <script src="js/isotope.js"></script>
   <script src="js/jquery.bootstrap-touchspin.js"></script>
   <script src="js/jquery.countTo.js"></script>
   <script src="js/jquery.easing.min.js"></script>
   <script src="js/jquery.enllax.min.js"></script>
   <script src="js/jquery.fancybox.js"></script>
   <script src="js/jquery.mixitup.min.js"></script>
   <script src="js/jquery.paroller.min.js"></script>
   <script src="js/owl.js"></script>
   <script src="js/validation.js"></script>
   <script src="js/wow.js"></script>

   <!---
<script src="js/gmaps.js"></script>
<script src="http://maps.google.com/maps/api/js?key=AIzaSyB2uu6KHbLc_y7fyAVA4dpqSVM4w9ZnnUw"></script>
<script src="js/mapapi.js"></script> 
--->
   <script src="js/map-helper.js"></script>

   <script src="assets/language-switcher/jquery.polyglot.language.switcher.js"></script>
   <script src="assets/timepicker/timePicker.js"></script>
   <script src="assets/html5lightbox/html5lightbox.js"></script>

   <!--Revolution Slider-->
   <script src="js/custom.js"></script>
   <script src="plugins/revolution/js/jquery.themepunch.revolution.min.js"></script>
   <script src="plugins/revolution/js/jquery.themepunch.tools.min.js"></script>
   <script src="plugins/revolution/js/extensions/revolution.extension.actions.min.js"></script>
   <script src="plugins/revolution/js/extensions/revolution.extension.carousel.min.js"></script>
   <script src="plugins/revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
   <script src="plugins/revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
   <script src="plugins/revolution/js/extensions/revolution.extension.migration.min.js"></script>
   <script src="plugins/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
   <script src="plugins/revolution/js/extensions/revolution.extension.parallax.min.js"></script>
   <script src="plugins/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
   <script src="plugins/revolution/js/extensions/revolution.extension.video.min.js"></script>
   <script src="js/main-slider-script.js"></script>
   <script src="js/lightbox.js"></script>
   <!-- thm custom script -->



   </body>


   <!-- Mirrored from st.ourhtmldemo.com/new/Crystalo/index-2.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 02 Aug 2024 04:31:55 GMT -->

   </html>